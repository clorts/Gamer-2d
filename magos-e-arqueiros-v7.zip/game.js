(() => {
const cv = document.getElementById('c'), ctx = cv.getContext('2d');
const W = 960, H = 540, GROUND = 470; let WORLD_W = 4200;

// ---------- Personagens e skins ----------
const RARITY = {
  comum:    {label:'COMUM',    color:'#b9c4d6'},
  rara:     {label:'RARA',     color:'#4da3ff'},
  lendaria: {label:'LENDÁRIA', color:'#ffb020'}
};
const CHARS = {
  bruxa: {
    name:'BRUXA', scale:.36, cw:300, ch:380, ax:150, ay:340, hw:17, hh:84, shotX:38, shotY:62, fire:2, cd:.5, ammo:'magic', shotSpeed:560,
    anims:{idle:{img:'idle',n:4,fps:6}, walk:{img:'walk',n:6,fps:9}, run:{img:'run',n:6,fps:14}, jump:{img:'jump',n:6,fps:10}, cast:{img:'cast',n:5,fps:13}, hurt:{img:'hurt',n:5,fps:8}},
    hurtFrame:t=>Math.min(2,Math.floor(t*8)), deadFrame:t=>Math.min(4,2+Math.floor(t*4)),
    jumpFrame:p=>{ if(p.vy<-250) return Math.min(2,Math.floor(p.t*10)); if(p.vy<-30) return 2; if(p.vy<=80) return 3; return p.vy>350?5:4; },
    skins:{
      classic:  {name:'BRUXA DA LUA',      rarity:'comum', dir:'classic',  shot:'#7dffa8', core:'#eafff0', glow:'80,255,140'},
      floresta: {name:'BRUXA DA FLORESTA', rarity:'rara',  dir:'floresta', shot:'#ffd24d', core:'#fff6d0', glow:'255,200,70'}
    }
  },
  arqueiro: {
    name:'ARQUEIRO', scale:.8, cw:260, ch:240, ax:130, ay:215, hw:15, hh:92, shotX:56, shotY:68, fire:2, cd:.42, ammo:'arrow', shotSpeed:800,
    anims:{idle:{img:'idle',n:4,fps:6}, walk:{img:'run',n:6,fps:9}, run:{img:'run',n:6,fps:14}, jump:{img:'jump',n:4,fps:10}, cast:{img:'cast',n:6,fps:14}, hurt:{img:'hurt',n:4,fps:8}},
    hurtFrame:()=>0, deadFrame:t=>Math.min(3,Math.floor(t*5)),
    jumpFrame:p=>{ if(p.vy<-120) return p.t<.08?0:1; return 2; }, landFrame:3,
    skins:{
      padrao: {name:'ARQUEIRO DA MATA', rarity:'comum', dir:'arqueiro', shot:'#c8a165', core:'#fff', glow:'255,230,150'},
      elfo:    {name:'ARQUEIRO ÉLFICO',   rarity:'rara',  dir:'arqueiro_elfo',    shot:'#9be86a', core:'#f4ffe0', glow:'150,235,100', anims:{cast:{n:5}}},
      deserto: {name:'ARQUEIRO DO DESERTO', rarity:'rara', dir:'arqueiro_deserto', shot:'#e8c27a', core:'#fff6dc', glow:'240,200,120'}
    }
  }
};
CHARS.cavaleiro = {
  name:'CAVALEIRO', scale:.72, cw:300, ch:220, ax:150, ay:195, hw:20, hh:90, shotX:0, shotY:0, fire:3, cd:.5, ammo:'melee', shotSpeed:0,
  anims:{idle:{img:'idle',n:4,fps:6}, walk:{img:'run',n:7,fps:9}, run:{img:'run',n:7,fps:14}, jump:{img:'jump',n:4,fps:10}, cast:{img:'cast',n:5,fps:12}, hurt:{img:'idle',n:4,fps:8}},
  deadImg:'death',
  hurtFrame:()=>0, deadFrame:(t,n)=>Math.min(n-1,Math.floor(t*6)),
  jumpFrame:(p,n)=>{ if(p.vy<-120) return p.t<.08?0:1; return n>=5?(p.vy>150?3:2):2; }, landFrame:(n)=>n-1,
  skins:{
    gelo:  {name:'CAVALEIRO DE GELO',  rarity:'rara',     dir:'gelo',  shot:'#9be8ff', core:'#ffffff', glow:'120,220,255', deathN:6, anims:{run:{n:7},jump:{n:4},cast:{n:5,fps:12,fire:3}}},
    fogo:  {name:'CAVALEIRO DE FOGO',  rarity:'lendaria', dir:'fogo',  shot:'#ff9a2e', core:'#fff2a0', glow:'255,150,40',  deathN:4, anims:{run:{n:6},jump:{n:5},cast:{n:6,fps:14,fire:2}}}
  }
};
CHARS.fenix = {
  name:'FÊNIX', scale:.85, cardK:1.25, cw:300, ch:220, ax:150, ay:195, hw:18, hh:92, shotX:0, shotY:0, fire:2, cd:.45, ammo:'melee', shotSpeed:0,
  anims:{idle:{img:'idle',n:6,fps:7}, walk:{img:'run',n:6,fps:9}, run:{img:'run',n:6,fps:14}, jump:{img:'jump',n:6,fps:10}, cast:{img:'cast',n:6,fps:13}, hurt:{img:'death',n:3,fps:8}},
  deadImg:'death',
  hurtFrame:()=>0, deadFrame:(t,n)=>Math.min(n-1,Math.floor(t*5)),
  jumpFrame:p=>{ if(p.vy<-120) return p.t<.08?0:1; if(p.vy<=80) return 2; return p.vy>400?5:(p.vy>200?4:3); },
  skins:{
    padrao: {name:'FÊNIX ARDENTE', rarity:'lendaria', dir:'fenix', shot:'#ff8a2a', core:'#fff2a0', glow:'255,140,40', deathN:3}
  }
};
CHARS.sombra = {
  name:'SOMBRA', scale:1, cardK:1.55, cw:422, ch:143, ax:249, ay:133, hw:17, hh:92, shotX:0, shotY:0, fire:3, cd:.5, ammo:'melee', shotSpeed:0, meleeW:240,
  anims:{idle:{img:'idle',n:4,fps:6}, walk:{img:'walk',n:10,fps:11}, run:{img:'run',n:6,fps:14}, jump:{img:'jump',n:6,fps:10}, cast:{img:'cast',n:6,fps:14}, hurt:{img:'death',n:5,fps:8}},
  deadImg:'death',
  hurtFrame:()=>0, deadFrame:(t,n)=>Math.min(n-1,Math.floor(t*5)),
  jumpFrame:p=>{ if(p.vy<-250) return Math.min(2,Math.floor(p.t*10)); if(p.vy<-30) return 2; if(p.vy<=80) return 3; return p.vy>350?5:4; },
  skins:{ padrao:{name:'SOMBRA DO CABELO', rarity:'comum', dir:'sombra', shot:'#b44dff', core:'#f1d6ff', glow:'180,80,255', deathN:5} }
};
CHARS.estudante = {
  name:'ESTUDANTE', scale:1, cardK:1.6, cw:138, ch:142, ax:59, ay:135, hw:15, hh:100, shotX:0, shotY:0, fire:2, cd:.5, ammo:'melee', shotSpeed:0,
  anims:{idle:{img:'idle',n:3,fps:5}, walk:{img:'run',n:4,fps:8}, run:{img:'run',n:4,fps:12}, jump:{img:'jump',n:4,fps:10}, cast:{img:'cast',n:5,fps:12}, hurt:{img:'death',n:3,fps:8}},
  deadImg:'death',
  hurtFrame:()=>0, deadFrame:(t,n)=>Math.min(n-1,Math.floor(t*4)),
  jumpFrame:p=>{ if(p.vy<-120) return p.t<.08?0:1; return 2; }, landFrame:3,
  skins:{ padrao:{name:'ESTUDANTE DA ESCOLA', rarity:'comum', dir:'estudante', shot:'#ffe6a0', core:'#ffffff', glow:'255,230,150', deathN:3} }
};
const CHAR_IDS = Object.keys(CHARS);
const animOf = (c,sk,name) => Object.assign({}, c.anims[name], (sk.anims||{})[name]);
const store = {
  get:(k,d)=>{ try{ const v=localStorage.getItem(k); return v===null?d:v; }catch(e){ return d; } },
  set:(k,v)=>{ try{ localStorage.setItem(k,v); }catch(e){} }
};
// ---------- Moedas e desbloqueios ----------
let coins = parseInt(store.get('ma_coins','0'),10)||0;
let unlocked; try{ unlocked = JSON.parse(store.get('ma_unlocked','null')); }catch(e){ unlocked=null; }
if (!Array.isArray(unlocked)) unlocked = [];
for (const k of ['bruxa:classic','arqueiro:padrao','sombra:padrao','estudante:padrao']) if(!unlocked.includes(k)) unlocked.push(k);   // só estes são grátis (Sombra e Estudante são personagens grátis)
const PRICE = {'bruxa:floresta':300, 'cavaleiro:gelo':500, 'arqueiro:elfo':200, 'arqueiro:deserto':200, 'fenix:padrao':520};   // 'cavaleiro:fogo' só ganha vencendo o boss
const isUn = (ch,sk) => unlocked.includes(ch+':'+sk);
const hasUn = ch => Object.keys(CHARS[ch].skins).some(k=>isUn(ch,k));
function unlock(ch,sk){ if(!isUn(ch,sk)){ unlocked.push(ch+':'+sk); store.set('ma_unlocked',JSON.stringify(unlocked)); } }
function addCoins(n){ coins=Math.max(0,coins+n); store.set('ma_coins',String(coins)); }

let selChar = store.get('jg_char','bruxa'); if(!CHARS[selChar]||!hasUn(selChar)) selChar='bruxa';
const selSkin = {};
for (const id of CHAR_IDS){
  let s = store.get('jg_skin_'+id, null);
  const all = Object.keys(CHARS[id].skins);
  if (!s || !CHARS[id].skins[s]) s = all[0];
  if (!isUn(id,s)){ const u = all.find(k=>isUn(id,k)); if (u) s=u; }
  selSkin[id] = s;
}
const CH_ = () => CHARS[selChar];
const SKN = () => CH_().skins[selSkin[selChar]];
function equip(ch, sk){ if(!isUn(ch,sk)) return false; selChar=ch; selSkin[ch]=sk; store.set('jg_char',ch); store.set('jg_skin_'+ch,sk); return true; }
function selectChar(ch){ selChar=ch; if(hasUn(ch)) store.set('jg_char',ch); }
const skinIds = ch => Object.keys(CHARS[ch].skins);
const landOf = (c,n) => typeof c.landFrame==='function' ? c.landFrame(n) : c.landFrame;

// ---------- Carregamento ----------
const IMG = {};
const toLoad = [];
for (const c of CHAR_IDS) for (const s in CHARS[c].skins){
  const dir = CHARS[c].skins[s].dir;
  if (IMG[dir]) continue; IMG[dir] = {};
  const names = Object.values(CHARS[c].anims).map(a=>a.img); if (CHARS[c].deadImg) names.push(CHARS[c].deadImg);
  for (const f of names){ if (IMG[dir][f]) continue;
    const i = new Image(); IMG[dir][f] = i; toLoad.push({i, src:'assets/'+dir+'/'+f+'.png'}); }
}
const BOSS_IMGS=['statue_idle','statue_detach','statue_headless','skull_a','skull_dash','skull_roar','skull_ball','skull_breath','skull_tired','skull_sparks','skull_fire','skull_plain','cadeado','bau'];
IMG.boss = {};
for (const n of BOSS_IMGS){ const i=new Image(); IMG.boss[n]=i; toLoad.push({i, src:'assets/boss/'+n+'.png'}); }
let loaded = 0; const total = toLoad.length;
let shownPct = 0;
const elLoad = document.getElementById('loading'), elBar = document.getElementById('lava');
for (const t of toLoad){ const done=()=>{loaded++;}; t.i.onload=done; t.i.onerror=done; t.i.src=t.src; }
(function loadTick(){
  const real = loaded/total*100;
  shownPct = Math.min(real, shownPct + 0.45 + Math.random()*0.5);
  const p = Math.floor(shownPct);
  elBar.style.width = p+'%';
  if (p>=100){ elBar.style.width='100%'; setTimeout(()=>{ elLoad.classList.add('hide'); setTimeout(()=>elLoad.remove(),500); start(); },350); return; }
  requestAnimationFrame(loadTick);
})();

// ---------- Audio ----------
let AC = null;
function beep(f, d, type='square', v=0.05, slide=0){
  try{
    AC = AC || new (window.AudioContext||window.webkitAudioContext)();
    const o = AC.createOscillator(), g = AC.createGain();
    o.type=type; o.frequency.value=f; if(slide) o.frequency.exponentialRampToValueAtTime(Math.max(30,f+slide), AC.currentTime+d);
    g.gain.value=v; g.gain.exponentialRampToValueAtTime(0.0001, AC.currentTime+d);
    o.connect(g).connect(AC.destination); o.start(); o.stop(AC.currentTime+d);
  }catch(e){}
}

// ---------- Entrada ----------
const keys = {}; const press = {};
addEventListener('keydown', e => {
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key)) e.preventDefault();
  if(!keys[e.code]) press[e.code]=true; keys[e.code]=true;
});
addEventListener('keyup', e => { keys[e.code]=false; });
const touch = {l:false,r:false,j:false,c:false};
function bindBtn(id, k){
  const el = document.getElementById(id);
  const on = e => { e.preventDefault(); touch[k]=true; if(k==='j') press.TJ=true; if(k==='c') press.TC=true; if(k==='l') press.TL=true; if(k==='r') press.TR=true; el.classList.add('on'); };
  const off = e => { e.preventDefault(); touch[k]=false; el.classList.remove('on'); };
  el.addEventListener('touchstart',on,{passive:false}); el.addEventListener('touchend',off,{passive:false}); el.addEventListener('touchcancel',off,{passive:false});
  el.addEventListener('mousedown',on); el.addEventListener('mouseup',off); el.addEventListener('mouseleave',off);
}
const touchEl = document.getElementById('touch');
bindBtn('bl','l'); bindBtn('br','r'); bindBtn('bj','j'); bindBtn('bc','c');
const left = () => keys.ArrowLeft||keys.KeyA||touch.l;
const right = () => keys.ArrowRight||keys.KeyD||touch.r;

// ---------- Layout dos menus ----------
const cardRect = i => { const n=CHAR_IDS.length, w=n>5?148:(n>3?215:250), g=n>5?8:(n>3?15:20), tot=n*w+(n-1)*g; return {x:Math.round(W/2-tot/2)+i*(w+g),y:130,w,h:280}; };
const iconRect = i => { const c=cardRect(i); return {x:c.x+c.w-52,y:c.y+8,w:44,h:44}; };
const playBtn = {x:W/2-235,y:430,w:220,h:50};
const bossBtn = {x:W/2+15,y:430,w:220,h:50};
const skinRect = (k,n) => ({x:W/2-(n*220+(n-1)*20)/2+k*240,y:110,w:220,h:300});
const backBtn = {x:W/2-90,y:480,w:180,h:42};
const inR = (x,y,r) => x>r.x&&x<r.x+r.w&&y>r.y&&y<r.y+r.h;
let skinCursor = 0;
function openSkins(){ skinCursor=Math.max(0,skinIds(selChar).indexOf(selSkin[selChar])); state='skins'; beep(480,.08,'triangle',.05,200); }

cv.addEventListener('pointerdown', e => {
  if (state==='play') return;
  const r = cv.getBoundingClientRect(), x=(e.clientX-r.left)/r.width*W, y=(e.clientY-r.top)/r.height*H;
  if (state==='title'){
    if (inR(x,y,iconRect(CHAR_IDS.indexOf(selChar)))) { openSkins(); return; }
    for (let i=0;i<CHAR_IDS.length;i++) if (inR(x,y,cardRect(i))){ if(CHAR_IDS[i]!==selChar){ selectChar(CHAR_IDS[i]); beep(520,.08,'triangle',.05,200); } return; }
    if (inR(x,y,playBtn)) press.Enter=true;
    if (inR(x,y,bossBtn)) press.KeyB=true;
  } else if (state==='skins'){
    const ids=skinIds(selChar);
    for (let k=0;k<ids.length;k++) if (inR(x,y,skinRect(k,ids.length))){ skinAction(k); return; }
    if (inR(x,y,backBtn)) state='title';
  } else press.Enter = true;
});

// ---------- Mundo ----------
const PLAT_N = [
  {x:350,y:370,w:200},{x:700,y:310,w:180},{x:1050,y:380,w:220},{x:1400,y:320,w:200},
  {x:1750,y:360,w:160},{x:2050,y:290,w:220},{x:2450,y:370,w:200},{x:2800,y:310,w:180},
  {x:3150,y:380,w:220},{x:3500,y:320,w:200},{x:3850,y:360,w:200}
];
const PLAT_B = [{x:300,y:380,w:200},{x:900,y:380,w:200},{x:90,y:300,w:150},{x:1160,y:300,w:150}];
let platforms = PLAT_N;
const stars = Array.from({length:90},()=>({x:Math.random()*W,y:Math.random()*300,s:Math.random()*2+1,t:Math.random()*6}));
let player, enemies, shots, parts, texts, camX, score, best = +(store.get('bruxa_best','0')), state='title', wave, spawnT, time=0, deadT=0;
let mode='normal', boss=null, chest=null, fballs=[], winT=0, banner=null, skinMsg={t:0,s:'',c:'#fff'}, gotFire=false;

function reset(m){ mode=m||'normal';
  player = {melee:null,x:200,y:GROUND,vx:0,vy:0,dir:1,hp:5,maxhp:5,ground:true,anim:'idle',t:0,moveT:0,castT:0,castCd:0,inv:0,hurtT:0,dead:false,shot:false,coyote:0,landT:0};
  enemies=[]; shots=[]; parts=[]; texts=[]; camX=0; score=0; wave=1; spawnT=1; time=0;
  fballs=[]; chest=null; boss=null; banner=null; winT=0;
  if (mode==='boss'){ WORLD_W=1400; platforms=PLAT_B; boss=makeBoss(); player.x=220; spawnT=1e9; banner={t:2.4,text:'CAVEIRA DE FOGO',col:'#ff9a2e'}; }
  else { WORLD_W=4200; platforms=PLAT_N; }
}

const hitbox = p => { const c=CH_(); return {x:p.x-c.hw,y:p.y-c.hh,w:c.hw*2,h:c.hh}; };
const overlap = (a,b) => a.x<b.x+b.w && a.x+a.w>b.x && a.y<b.y+b.h && a.y+a.h>b.y;
function burst(x,y,col,n=10,sp=140){ for(let i=0;i<n;i++){const a=Math.random()*6.28,s=Math.random()*sp+30; parts.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-40,l:.5+Math.random()*.3,c:col,s:3+Math.random()*3});} }
function floatText(x,y,t,c='#9dffb5'){ texts.push({x,y,t,c,l:1}); }

function spawnEnemy(){
  const side = Math.random()<.5 ? -1 : 1;
  let x = player.x + side*(W/2+80); x = Math.max(60,Math.min(WORLD_W-60,x));
  if (Math.abs(x-player.x)<W/2) { x = player.x - side*(W/2+80); x=Math.max(60,Math.min(WORLD_W-60,x)); }
  if (Math.random() < Math.min(.15+wave*.07,.5)) enemies.push({type:'bat',x,y:200+Math.random()*120,w:34,h:24,hp:1,vx:0,vy:0,t:Math.random()*6,dir:1});
  else enemies.push({type:'slime',x,y:GROUND,w:40,h:28,hp:2+(wave>3?1:0),vx:0,vy:0,t:Math.random()*6,dir:1,hop:0});
}

function reward(e,pts){ floatText(e.x,e.y-e.h-6,'+'+pts); const c=e.type==='bat'?5:3; addCoins(c); floatText(e.x,e.y-e.h-24,'+'+c,'#ffd24d'); }

function hurtPlayer(from){
  if (player.inv>0 || player.dead) return;
  player.hp--; player.inv=1.4; player.hurtT=.55; player.t=0; player.castT=0;
  player.vx = (player.x<from?-1:1)*220; player.vy=-260; player.ground=false;
  beep(160,.25,'sawtooth',.07,-90); burst(player.x,player.y-50,'#ff5577',10);
  if (player.hp<=0){ player.dead=true; player.t=0; state='dead'; deadT=0; if(score>best){best=score;store.set('bruxa_best',best);} }
}

// ---------- Atualização ----------
function update(dt){
  time+=dt;
  const p = player, c = CH_(), sk0 = SKN();
  p.castCd=Math.max(0,p.castCd-dt); p.inv=Math.max(0,p.inv-dt); p.hurtT=Math.max(0,p.hurtT-dt); p.landT=Math.max(0,p.landT-dt);

  if (!p.dead) {
    const stunned = p.hurtT>0, casting = p.castT>0;
    let mv = 0;
    if (!stunned){ if(left()) mv-=1; if(right()) mv+=1; }
    if (mv!==0){ p.dir=mv; p.moveT+=dt; } else p.moveT=0;
    const maxSp = casting ? 0 : (p.moveT>.4 ? 270 : 150);
    if (!stunned){ const target=mv*maxSp; p.vx += (target-p.vx)*Math.min(1,dt*12); }
    else p.vx*= (1-Math.min(1,dt*3));

    p.coyote = p.ground ? .1 : p.coyote-dt;
    const jp = press.Space||press.KeyW||press.ArrowUp||press.TJ;
    if (jp && !stunned && p.coyote>0){ p.vy=-560; p.ground=false; p.coyote=0; p.t=0; beep(420,.15,'square',.04,300); }
    if (!(keys.Space||keys.KeyW||keys.ArrowUp||touch.j) && p.vy<-200) p.vy+= 1800*dt;

    const cp = press.KeyJ||press.KeyK||press.KeyZ||press.KeyX||press.TC;
    if (cp && !stunned && p.castCd<=0 && p.castT<=0){ const ca0=animOf(c,sk0,'cast'); p.castT=ca0.n/ca0.fps; p.castCd=c.cd; p.shot=false; p.t=0; p.anim='cast'; if(c.ammo!=='melee') beep(c.ammo==='arrow'?300:660,.18,c.ammo==='arrow'?'sawtooth':'triangle',.05,c.ammo==='arrow'?-120:500); }
    if (p.castT>0){
      p.castT-=dt;
      const ca=animOf(c,sk0,'cast'), fi = Math.floor(p.t*ca.fps), fireAt = ca.fire!==undefined?ca.fire:c.fire;
      if (!p.shot && fi>=fireAt){
        p.shot=true;
        if (c.ammo==='melee'){ p.melee={t:.2,hit:new Set()}; beep(200,.2,'sawtooth',.06,-80); }
        else shots.push({x:p.x+p.dir*c.shotX,y:p.y-c.shotY,vx:p.dir*c.shotSpeed,l:1.1,dir:p.dir,t:0,kind:c.ammo,skin:sk0});
      }
    }

    p.vy+=1500*dt;
    p.x+=p.vx*dt; p.x=Math.max(30,Math.min(WORLD_W-30,p.x));
    const py=p.y, wasGround=p.ground; p.y+=p.vy*dt; p.ground=false;
    if (p.y>=GROUND){ p.y=GROUND; p.vy=0; p.ground=true; }
    else if (p.vy>=0) for (const pl of platforms){
      if (p.x+12>pl.x && p.x-12<pl.x+pl.w && py<=pl.y+2 && p.y>=pl.y){ p.y=pl.y; p.vy=0; p.ground=true; break; }
    }
    if (p.ground && !wasGround && c.landFrame!==undefined) p.landT=.12;
    if (p.melee){ p.melee.t-=dt; const mw=c.meleeW||135, mr = p.dir>0 ? {x:p.x-10,y:p.y-125,w:mw,h:125} : {x:p.x+10-mw,y:p.y-125,w:mw,h:125};
      for (const e of enemies){ if(e.dead||p.melee.hit.has(e)) continue; if(overlap(mr,{x:e.x-e.w/2,y:e.y-e.h,w:e.w,h:e.h})){ p.melee.hit.add(e); e.hp-=2; e.flash=.12; e.vx=p.dir*260; burst(e.x,e.y-e.h/2,sk0.shot,10);
        if(e.hp<=0){ e.dead=true; const pts=e.type==='bat'?15:10; score+=pts; reward(e,pts); burst(e.x,e.y-e.h/2,e.type==='bat'?'#b57cff':'#5be37a',16); beep(300,.15,'square',.05,-150);} else beep(500,.06,'square',.04); } }
      if (bossHittable() && !p.melee.hit.has('boss')){ const hr0=headRect(boss); if (overlap(mr,hr0)){ p.melee.hit.add('boss'); damageBoss(3,sk0.shot,hr0.x+hr0.w/2,hr0.y+hr0.h/2); } }
      if (p.melee.t<=0) p.melee=null; }

    let a;
    if (stunned) a='hurt';
    else if (p.castT>0) a='cast';
    else if (!p.ground) a='jump';
    else if (p.landT>0 && Math.abs(p.vx)<60 && c.landFrame!==undefined) a='land';
    else if (Math.abs(p.vx)>200) a='run';
    else if (Math.abs(p.vx)>30) a='walk';
    else a='idle';
    if (a!==p.anim){ p.anim=a; if(a!=='jump') p.t=0; }
    p.t+=dt;
  } else {
    p.t+=dt; p.vx*=.9; p.vy+=1500*dt; p.y=Math.min(GROUND,p.y+p.vy*dt); if(p.y>=GROUND)p.vy=0; p.x+=p.vx*dt;
  }

  spawnT-=dt;
  if (!p.dead && mode==='normal' && spawnT<=0){
    if (enemies.length<4+wave*2) spawnEnemy();
    spawnT = Math.max(.7, 2.2-wave*.18);
  }
  wave = 1+Math.floor(score/120);

  for (const s of shots){
    s.t+=dt; s.l-=dt; s.x+=s.vx*dt;
    if (s.kind==='magic' && Math.random()<.7) parts.push({x:s.x,y:s.y+(Math.random()-.5)*8,vx:-s.dir*40,vy:(Math.random()-.5)*40,l:.3,c:s.skin.shot,s:3});
    for (const e of enemies){
      if (e.dead) continue;
      if (s.x>e.x-e.w/2-8 && s.x<e.x+e.w/2+8 && s.y>e.y-e.h-8 && s.y<e.y+8){
        e.hp--; s.l=0; e.flash=.12; e.vx=s.dir*160; burst(s.x,s.y,s.skin.shot,8);
        if (e.hp<=0){ e.dead=true; const pts=e.type==='bat'?15:10; score+=pts; reward(e,pts); burst(e.x,e.y-e.h/2,e.type==='bat'?'#b57cff':'#5be37a',16); beep(300,.15,'square',.05,-150); }
        else beep(500,.06,'square',.04);
        break;
      }
    }
  }
  if (bossHittable()) for (const s of shots){ if(s.l<=0) continue; const r=headRect(boss);
    if (s.x>r.x-8&&s.x<r.x+r.w+8&&s.y>r.y-8&&s.y<r.y+r.h+8){ s.l=0; damageBoss(1,s.skin.shot,s.x,s.y); } }
  shots=shots.filter(s=>s.l>0);

  const hb=hitbox(p);
  for (const e of enemies){
    e.t+=dt; e.flash=Math.max(0,(e.flash||0)-dt);
    e.dir = player.x>e.x?1:-1;
    if (e.type==='slime'){
      e.hop-=dt; e.vy+=1500*dt; e.y+=e.vy*dt;
      if (e.y>=GROUND){ e.y=GROUND; e.vy=0; if(e.hop<=0){ e.vy=-340; e.vx=e.dir*(80+wave*8); e.hop=.9+Math.random()*.6; } else e.vx*=.8; }
      e.x+=e.vx*dt;
    } else {
      const sp=70+wave*8;
      e.x+=(e.dir*sp+e.vx)*dt; e.vx*=.9;
      const ty=Math.min(GROUND-50,Math.max(120,player.y-70+Math.sin(e.t*3)*50));
      e.y+=(ty-e.y)*Math.min(1,dt*1.5);
    }
    if (!p.dead && overlap(hb,{x:e.x-e.w/2+4,y:e.y-e.h+3,w:e.w-8,h:e.h-3})) hurtPlayer(e.x);
  }
  enemies=enemies.filter(e=>!e.dead && Math.abs(e.x-player.x)<2500);

  updateBoss(dt);
  if (state==='win') winT+=dt;
  if (banner){ banner.t-=dt; if(banner.t<=0) banner=null; }
  for (const q of parts){ q.l-=dt; q.x+=q.vx*dt; q.y+=q.vy*dt; q.vy+=300*dt; }
  parts=parts.filter(q=>q.l>0);
  for (const t of texts){ t.l-=dt; t.y-=30*dt; }
  texts=texts.filter(t=>t.l>0);

  camX += ((p.x-W/2+p.dir*60)-camX)*Math.min(1,dt*5);
  camX = Math.max(0,Math.min(WORLD_W-W,camX));
  if (p.dead) deadT+=dt;
}


// ---------- Boss: Caveira de Fogo ----------
const BS = 1.1, BOSS_HP = 70;
const BANIM = {skull_a:[40,50], skull_dash:[130,45], skull_roar:[52,58], skull_ball:[46,53], skull_breath:[42,90], skull_tired:[40,54], skull_sparks:[80,75], skull_fire:[88,92], skull_plain:[37,50]};
const SEQ1=['ball','dash','ball','breath','tired'], SEQ2=['dash','ball','breath','dash','breath','tired'];
function makeBoss(){ return {x:700,hx:754,hy:GROUND-150,face:-1,hp:BOSS_HP,maxhp:BOSS_HP,st:'intro',t:0,sub:0,fired:0,seq:0,phase:1,flash:0,bob:0,dead:false,dir:1,sx:0,sy:0,tx:0,ty:0,lockY:0,dvy:0}; }
const headRect = b => ({x:b.hx-36,y:b.hy-44,w:72,h:88});
const bossHittable = () => !!boss && !boss.dead && !['intro','detach','dying','dead'].includes(boss.st);
const beamRect = b => { const x0=b.hx+b.dir*36, x1=b.hx+b.dir*340; return {x:Math.min(x0,x1),y:b.hy-28,w:Math.abs(x1-x0),h:62}; };
function setHover(b){ const p=player, side=Math.random()<.5?-1:1; b.tx=Math.max(140,Math.min(WORLD_W-140,p.x+side*(200+Math.random()*140))); b.ty=GROUND-95-Math.random()*115; b.st='hover'; b.t=0; }
function bossNext(b){
  const seq=b.phase===1?SEQ1:SEQ2, a=seq[b.seq%seq.length], p=player; b.seq++; b.st=a; b.t=0; b.sub=0; b.fired=0;
  if (a==='dash'){ b.sx=p.x<WORLD_W/2?WORLD_W-110:110; b.dir=b.sx>p.x?-1:1; b.lockY=p.y-48; }
  if (a==='breath'){ const side=Math.random()<.5?-1:1; b.sx=Math.max(120,Math.min(WORLD_W-120,p.x+side*330)); b.dir=p.x>b.sx?1:-1; b.sy=Math.random()<.6?GROUND-52:GROUND-165; }
}
function shootBall(b){
  const p=player, sx=b.hx+b.face*30, sy=b.hy+10; const dx=p.x-sx, dy=(p.y-45)-sy, d=Math.hypot(dx,dy)||1, spd=b.phase===2?370:310;
  fballs.push({x:sx,y:sy,vx:dx/d*spd,vy:dy/d*spd,l:1,t:0}); beep(240,.18,'sawtooth',.05,-120); burst(sx,sy,'#ff9a2e',6,90);
}
function damageBoss(d,col,x,y){
  const b=boss; if(!bossHittable()) return false;
  if (b.st==='tired') d*=2;
  b.hp-=d; b.flash=.1; burst(x,y,col,8); beep(b.st==='tired'?700:520,.06,'square',.04);
  if (b.hp>0 && b.phase===1 && b.hp<=b.maxhp/2){ b.phase=2; banner={t:1.6,text:'FÚRIA!',col:'#ff7a2e'}; beep(100,.5,'sawtooth',.07,200); }
  if (b.hp<=0){ b.hp=0; b.st='dying'; b.t=0; b.dvy=-160; fballs=[]; beep(90,.8,'sawtooth',.08,-40); }
  return true;
}
function openChest(){
  chest.got=true; addCoins(200); const first=!isUn('cavaleiro','fogo'); unlock('cavaleiro','fogo'); gotFire=first;
  for (let i=0;i<40;i++) parts.push({x:chest.x,y:chest.y-40,vx:(Math.random()-.5)*420,vy:-Math.random()*460-80,l:.9+Math.random()*.5,c:Math.random()<.6?'#ffd24d':'#fff3a0',s:4+Math.random()*3});
  floatText(chest.x,chest.y-90,'+200 MOEDAS','#ffd24d'); beep(660,.12,'triangle',.06,400); setTimeout(()=>beep(990,.25,'triangle',.06,300),120);
  state='win'; winT=0;
}
function updateBoss(dt){
  const p=player;
  for (const f of fballs){
    f.t+=dt; f.x+=f.vx*dt; f.y+=f.vy*dt;
    if (Math.random()<.8) parts.push({x:f.x,y:f.y,vx:(Math.random()-.5)*40,vy:(Math.random()-.5)*40,l:.3,c:Math.random()<.5?'#ff9a2e':'#ffd24d',s:3+Math.random()*3});
    if (!p.dead && overlap(hitbox(p),{x:f.x-10,y:f.y-10,w:20,h:20})){ f.l=0; hurtPlayer(f.x); burst(f.x,f.y,'#ff9a2e',10); }
    else if (f.y>GROUND+6){ f.l=0; burst(f.x,GROUND,'#ff9a2e',8,100); }
    if (f.x<-60||f.x>WORLD_W+60||f.t>5) f.l=0;
  }
  fballs=fballs.filter(f=>f.l>0);
  if (chest && !chest.got){
    chest.t+=dt; chest.vy+=1500*dt; chest.y+=chest.vy*dt;
    if (chest.y>=GROUND){ chest.y=GROUND; chest.vy=0; chest.landed=true; }
    if (chest.landed && !p.dead && overlap(hitbox(p),{x:chest.x-45,y:chest.y-70,w:90,h:70})) openChest();
  }
  const b=boss; if(!b) return;
  const sp=b.phase===2?1.3:1; b.t+=dt; b.flash=Math.max(0,b.flash-dt); b.bob+=dt;
  const mv=(tx,ty,k)=>{ const f=Math.min(1,dt*k); b.hx+=(tx-b.hx)*f; b.hy+=(ty-b.hy)*f; };
  const hb=hitbox(p), hr=headRect(b);
  switch(b.st){
    case 'intro': if(b.t>2.4){ b.st='detach'; b.t=0; beep(110,.6,'sawtooth',.07,220); } break;
    case 'detach': if(b.t>1.1){ b.hx=b.x+54; b.hy=GROUND-150; burst(b.hx,b.hy,'#ff9a2e',24,220); setHover(b); } break;
    case 'hover': b.face=p.x>b.hx?1:-1; mv(b.tx,b.ty+Math.sin(b.bob*3)*10,2.6); if(b.t>1.15/sp) bossNext(b); break;
    case 'ball': {
      b.face=p.x>b.hx?1:-1; mv(b.tx,b.ty+Math.sin(b.bob*4)*8,1.6);
      const gap=.3/sp, n=b.phase===2?5:3;
      if (b.fired<n && b.t>.55+b.fired*gap){ shootBall(b); b.fired++; }
      if (b.t>.55+n*gap+.35) setHover(b);
      break; }
    case 'dash':
      if (b.sub===0){
        const tel=.85/sp; if (b.t<tel*.65) b.lockY=Math.max(GROUND-230,Math.min(GROUND-40,p.y-48));
        mv(b.sx,b.lockY,b.t<tel*.65?5:12); b.face=b.dir;
        if (b.t>tel){ b.sub=1; b.t=0; beep(220,.4,'sawtooth',.07,300); }
      } else {
        b.face=b.dir; b.hx+=b.dir*820*sp*dt;
        parts.push({x:b.hx-b.dir*40,y:b.hy+(Math.random()-.5)*50,vx:-b.dir*60,vy:(Math.random()-.5)*40,l:.3,c:Math.random()<.5?'#ffd24d':'#ff7a2e',s:4});
        if (!p.dead && overlap(hb,{x:hr.x+8,y:hr.y+8,w:hr.w-16,h:hr.h-16})) hurtPlayer(b.hx);
        if ((b.dir>0&&b.hx>WORLD_W-80)||(b.dir<0&&b.hx<80)) setHover(b);
      }
      break;
    case 'breath':
      if (b.sub===0){ mv(b.sx,b.sy,4); b.face=b.dir; if(b.t>1.0/sp){ b.sub=1; b.t=0; beep(180,1,'sawtooth',.07,-60); } }
      else {
        b.face=b.dir; b.hy+=(b.sy-b.hy)*Math.min(1,dt*8); const r=beamRect(b);
        if (!p.dead && overlap(hb,r)) hurtPlayer(b.hx);
        if (Math.random()<.9) parts.push({x:r.x+Math.random()*r.w,y:r.y+Math.random()*r.h,vx:b.dir*80,vy:-30,l:.3,c:Math.random()<.5?'#ffd24d':'#ff7a2e',s:3+Math.random()*3});
        if (b.t>1.5) setHover(b);
      }
      break;
    case 'tired': b.face=p.x>b.hx?1:-1; mv(b.hx,GROUND-78,3); if(b.t>2.9) setHover(b); break;
    case 'dying':
      b.dvy+=800*dt; b.hy+=b.dvy*dt; b.hx+=Math.sin(b.t*50)*2;
      if (Math.random()<.8) parts.push({x:b.hx+(Math.random()-.5)*50,y:b.hy+(Math.random()-.5)*50,vx:(Math.random()-.5)*120,vy:-Math.random()*120,l:.5,c:Math.random()<.5?'#ff9a2e':'#ffd24d',s:4+Math.random()*3});
      if (b.hy>=GROUND-42){
        b.hy=GROUND-42; b.st='dead'; b.dead=true;
        burst(b.hx,b.hy,'#ff9a2e',40,320); burst(b.hx,b.hy,'#ffd24d',30,260); beep(70,.9,'sawtooth',.09,-30);
        chest={x:b.hx,y:GROUND-60,vy:-260,landed:false,t:0,got:false}; banner={t:2.2,text:'CAVEIRA DERROTADA!',col:'#ffd24d'};
      }
      break;
  }
}

// ---------- Desenho ----------
function drawBG(){
  const g=ctx.createLinearGradient(0,0,0,H); g.addColorStop(0,'#0d0a24'); g.addColorStop(.6,'#2a1550'); g.addColorStop(1,'#4a2467');
  ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
  for (const s of stars){ const a=.5+.5*Math.sin(time*2+s.t); ctx.fillStyle=`rgba(255,255,230,${.3+a*.6})`; ctx.fillRect(Math.floor((s.x-camX*.03+W*3)%W),Math.floor(s.y),s.s,s.s); }
  ctx.fillStyle='#fff3c4'; ctx.beginPath(); ctx.arc(780-camX*.02,90,38,0,6.28); ctx.fill();
  ctx.fillStyle='#e3d08a'; ctx.beginPath(); ctx.arc(768-camX*.02,80,8,0,6.28); ctx.arc(795-camX*.02,104,5,0,6.28); ctx.fill();
  layer(.15,'#2a1a4d',380,70,.004); layer(.35,'#1d1238',420,55,.006);
  ctx.fillStyle='#120b24';
  for (let i=-2;i<24;i++){ const wx=i*190+((i*73)%60); const x=wx-camX*.6; if(x<-60||x>W+60) continue; const h=70+((i*37)%50); tree(x,GROUND+8,h); }
}
function layer(par,col,base,amp,fr){
  ctx.fillStyle=col; ctx.beginPath(); ctx.moveTo(0,H);
  for (let x=0;x<=W;x+=12){ const wx=x+camX*par; ctx.lineTo(x, base-Math.abs(Math.sin(wx*fr))*amp - Math.sin(wx*fr*2.3)*14); }
  ctx.lineTo(W,H); ctx.fill();
}
function tree(x,y,h){ ctx.fillRect(x-4,y-h*.35,8,h*.35); for(let k=0;k<4;k++){ const w=46-k*10, yy=y-h*.3-k*h*.2; ctx.beginPath(); ctx.moveTo(x-w/2,yy); ctx.lineTo(x+w/2,yy); ctx.lineTo(x,yy-h*.35); ctx.fill(); } }

function drawShot(s){
  ctx.save(); ctx.translate(Math.floor(s.x),Math.floor(s.y)); if(s.dir<0) ctx.scale(-1,1);
  if (s.kind==='arrow'){
    ctx.fillStyle='#8a5a2b'; ctx.fillRect(-26,-2,40,4);
    ctx.fillStyle='#5b3a1b'; ctx.fillRect(-26,1,40,1);
    ctx.fillStyle='#cfd6df'; ctx.fillRect(14,-4,6,8); ctx.fillRect(20,-2,4,4);
    ctx.fillStyle='#fff'; ctx.fillRect(-30,-5,8,3); ctx.fillRect(-30,2,8,3); ctx.fillRect(-26,-3,4,6);
  } else {
    ctx.fillStyle='rgba('+s.skin.glow+',.25)'; ctx.beginPath(); ctx.arc(0,0,16,0,6.28); ctx.fill();
    ctx.fillStyle=s.skin.shot; ctx.fillRect(-7,-7,14,14);
    ctx.fillStyle=s.skin.core; ctx.fillRect(-3,-3,6,6);
  }
  ctx.restore();
}


function headImg(name,x,y,sc,face){
  const im=IMG.boss[name], a=BANIM[name]||[im.width/2,im.height/2];
  ctx.save(); ctx.translate(Math.floor(x),Math.floor(y)); if(face<0) ctx.scale(-1,1);
  ctx.drawImage(im,-a[0]*sc,-a[1]*sc,im.width*sc,im.height*sc); ctx.restore();
}
function bossHeadSprite(b){
  switch(b.st){
    case 'ball': return b.t<.55?'skull_roar':'skull_ball';
    case 'dash': return b.sub===0?'skull_roar':'skull_dash';
    case 'breath': return b.sub===0?'skull_roar':'skull_breath';
    case 'tired': return Math.floor(b.t*4)%2?'skull_sparks':'skull_tired';
    case 'dying': return Math.floor(b.t*12)%2?'skull_fire':'skull_roar';
  }
  return 'skull_a';
}
function drawBoss(){
  const b=boss; if(!b) return; const I=IMG.boss;
  const body = b.st==='intro'?'statue_idle':(b.st==='detach'?'statue_detach':'statue_headless'), bi=I[body], bsc=1.2;
  ctx.drawImage(bi,Math.floor(b.x-bi.width*bsc/2),Math.floor(GROUND+6-bi.height*bsc),Math.floor(bi.width*bsc),Math.floor(bi.height*bsc));
  if (b.st==='intro'||b.st==='detach'||b.dead) return;
  // avisos de ataque
  const warn=.12+.1*Math.sin(b.t*30);
  if (b.st==='dash' && b.sub===0 && b.t>.3){ ctx.fillStyle='rgba(255,60,40,'+warn+')'; ctx.fillRect(camX-10,b.hy-30,W+20,60); }
  if (b.st==='breath' && b.sub===0){ const r=beamRect(b); ctx.fillStyle='rgba(255,60,40,'+warn+')'; ctx.fillRect(r.x,r.y,r.w,r.h); }
  const shake=(b.st==='dash'&&b.sub===0)||(b.st==='breath'&&b.sub===0)||b.st==='dying'?2:0;
  const x=b.hx+(Math.random()-.5)*shake*2, y=b.hy+(Math.random()-.5)*shake*2, spr=bossHeadSprite(b);
  if (b.phase===2 && b.st!=='dying' && b.st!=='breath'){ ctx.globalAlpha=.4+.15*Math.sin(time*9); headImg('skull_fire',x,y+4,1.0,1); ctx.globalAlpha=1; }
  headImg(spr,x,y,BS,b.face);
  if (b.flash>0){ ctx.globalCompositeOperation='lighter'; ctx.globalAlpha=.7; headImg(spr,x,y,BS,b.face); ctx.globalAlpha=1; ctx.globalCompositeOperation='source-over'; }
}
function drawChest(){
  if(!chest||chest.got) return; const im=IMG.boss.bau;
  if (chest.landed){ ctx.fillStyle='rgba(255,210,80,'+(.18+.1*Math.sin(time*6))+')'; ctx.beginPath(); ctx.arc(chest.x,chest.y-38,62+Math.sin(time*6)*4,0,6.28); ctx.fill(); }
  ctx.drawImage(im,Math.floor(chest.x-im.width/2),Math.floor(chest.y-im.height+4));
  if (chest.landed){ const a=.5+.5*Math.sin(time*8); ctx.fillStyle='rgba(255,255,200,'+a+')'; ctx.fillRect(chest.x-30+Math.sin(time*3)*20,chest.y-70-Math.cos(time*4)*10,4,4); }
}
function drawFballs(){
  for (const f of fballs){
    ctx.fillStyle='rgba(255,120,20,.3)'; ctx.beginPath(); ctx.arc(f.x,f.y,17,0,6.28); ctx.fill();
    ctx.fillStyle='#ff9a2e'; ctx.beginPath(); ctx.arc(f.x,f.y,10,0,6.28); ctx.fill();
    ctx.fillStyle='#fff2a0'; ctx.beginPath(); ctx.arc(f.x,f.y,5,0,6.28); ctx.fill();
  }
}
function drawBraziers(){
  for (const bx of [60,WORLD_W-60]){
    ctx.fillStyle='#2a1a2e'; ctx.fillRect(bx-14,GROUND-34,28,34); ctx.fillStyle='#46304a'; ctx.fillRect(bx-20,GROUND-40,40,8);
    const fl=Math.sin(time*14+bx)*4;
    ctx.fillStyle='rgba(255,120,20,.25)'; ctx.beginPath(); ctx.arc(bx,GROUND-62,34,0,6.28); ctx.fill();
    ctx.fillStyle='#ff7a2e'; ctx.fillRect(bx-10,GROUND-62,20,22); ctx.fillRect(bx-6,GROUND-74+fl,12,14);
    ctx.fillStyle='#ffd24d'; ctx.fillRect(bx-5,GROUND-58,10,16); ctx.fillStyle='#fff6c0'; ctx.fillRect(bx-2,GROUND-52,4,10);
  }
}
function bossHud(){
  const b=boss; if(!b) return; const bw=320, bx=W/2-bw/2, by=22;
  ctx.fillStyle='#000'; ctx.fillRect(bx-3,by-3,bw+6,22); ctx.fillStyle='#3a1208'; ctx.fillRect(bx,by,bw,16);
  ctx.fillStyle=b.phase===2?'#ff7a2e':'#e8452c'; ctx.fillRect(bx,by,bw*b.hp/b.maxhp,16);
  ctx.fillStyle='rgba(255,255,255,.25)'; ctx.fillRect(bx,by,bw*b.hp/b.maxhp,4);
  ctx.textAlign='center'; ctx.font='bold 13px monospace'; ctx.fillStyle='#ffd9a0';
  ctx.fillText('CAVEIRA DE FOGO'+(b.st==='tired'?'  (CANSADA! DANO x2)':''),W/2,by+36);
}
function drawBanner(){
  if(!banner) return; ctx.globalAlpha=Math.min(1,banner.t*1.5); centerText(banner.text,210,54,banner.col); ctx.globalAlpha=1;
}
function drawLock(cx,cy,h){ const im=IMG.boss.cadeado, sc=h/im.height; ctx.drawImage(im,Math.floor(cx-im.width*sc/2),Math.floor(cy-h/2),Math.floor(im.width*sc),Math.floor(h)); }
function coinIcon(x,y,r){
  ctx.fillStyle='#8a5a00'; ctx.beginPath(); ctx.arc(x,y,r+2,0,6.28); ctx.fill();
  ctx.fillStyle='#ffd24d'; ctx.beginPath(); ctx.arc(x,y,r,0,6.28); ctx.fill();
  ctx.fillStyle='#fff3a0'; ctx.beginPath(); ctx.arc(x-r*.25,y-r*.25,r*.45,0,6.28); ctx.fill();
  ctx.fillStyle='#c98a00'; ctx.fillRect(x-1,y-r*.5,2,r);
}
function coinCounter(rx,y){ ctx.font='bold 22px monospace'; ctx.textAlign='right'; ctx.fillStyle='#ffd24d'; ctx.fillText(String(coins),rx,y); const w=ctx.measureText(String(coins)).width; coinIcon(rx-w-18,y-7,9); }

function drawWorld(){
  ctx.save(); ctx.translate(-Math.floor(camX),0);
  ctx.fillStyle='#2b1d3f'; ctx.fillRect(camX-10,GROUND,W+20,H-GROUND);
  ctx.fillStyle='#3d8f4a'; ctx.fillRect(camX-10,GROUND,W+20,8);
  ctx.fillStyle='#2f7039'; for (let x=Math.floor(camX/16)*16;x<camX+W+16;x+=16) ctx.fillRect(x,GROUND+8,8,4);
  ctx.fillStyle='#1e1230'; for (let x=Math.floor(camX/48)*48;x<camX+W+48;x+=48) ctx.fillRect(x+10,GROUND+30,20,10);
  for (const pl of platforms){
    if (pl.x>camX+W||pl.x+pl.w<camX) continue;
    ctx.fillStyle='#5a3b2a'; ctx.fillRect(pl.x,pl.y,pl.w,16);
    ctx.fillStyle='#3d8f4a'; ctx.fillRect(pl.x,pl.y,pl.w,6);
    ctx.fillStyle='#46281c'; for(let x=pl.x+6;x<pl.x+pl.w-6;x+=24) ctx.fillRect(x,pl.y+9,12,3);
  }
  if (mode==='boss') drawBraziers();
  drawBoss(); drawChest();
  for (const e of enemies) drawEnemy(e);
  drawFballs();
  for (const s of shots) drawShot(s);
  drawPlayer();
  for (const q of parts){ ctx.globalAlpha=Math.max(0,q.l*2); ctx.fillStyle=q.c; ctx.fillRect(q.x,q.y,q.s,q.s); } ctx.globalAlpha=1;
  ctx.font='bold 16px monospace'; ctx.textAlign='center';
  for (const t of texts){ ctx.globalAlpha=Math.max(0,t.l); ctx.fillStyle=t.c; ctx.fillText(t.t,t.x,t.y); } ctx.globalAlpha=1;
  ctx.restore();
}

function drawEnemy(e){
  ctx.save(); ctx.translate(Math.floor(e.x),Math.floor(e.y)); if(e.dir<0) ctx.scale(-1,1);
  const fl = e.flash>0;
  if (e.type==='slime'){
    const sq = 1+Math.sin(e.t*8)*.08, w=e.w*sq, h=e.h/sq;
    ctx.fillStyle=fl?'#fff':'#3fb85c'; ctx.fillRect(-w/2,-h,w,h); ctx.fillRect(-w/2+4,-h-4,w-8,4);
    ctx.fillStyle=fl?'#fff':'#2a8c44'; ctx.fillRect(-w/2,-6,w,6);
    ctx.fillStyle='#fff'; ctx.fillRect(2,-h+6,9,9); ctx.fillRect(-12,-h+6,9,9);
    ctx.fillStyle='#142'; ctx.fillRect(6,-h+9,4,6); ctx.fillRect(-8,-h+9,4,6);
  } else {
    const fl2=Math.sin(e.t*22)>0;
    ctx.fillStyle=fl?'#fff':'#6b3fb0';
    ctx.fillRect(-8,-e.h+4,16,14);
    ctx.fillRect(-22,fl2?-e.h-4:-e.h+8,14,8); ctx.fillRect(8,fl2?-e.h-4:-e.h+8,14,8);
    ctx.fillRect(-16,fl2?-e.h-8:-e.h+12,8,6); ctx.fillRect(8,fl2?-e.h-8:-e.h+12,8,6);
    ctx.fillRect(-8,-e.h,4,6); ctx.fillRect(4,-e.h,4,6);
    ctx.fillStyle='#ff4d6d'; ctx.fillRect(0,-e.h+7,4,4); ctx.fillRect(-6,-e.h+7,4,4);
  }
  ctx.restore();
}

// retorna {img, f} para o personagem/skin dado
function frameFor(c, sk, p){
  const I = IMG[sk.dir];
  if (p.dead){ const n=sk.deathN||c.anims.hurt.n; return {img:I[c.deadImg||c.anims.hurt.img], f:c.deadFrame(p.t,n)}; }
  const A = n => animOf(c,sk,n);
  switch (p.anim){
    case 'hurt': { const a=A('hurt'); return {img:I[a.img], f:c.hurtFrame(p.t)}; }
    case 'jump': { const a=A('jump'); return {img:I[a.img], f:c.jumpFrame(p,a.n)}; }
    case 'land': { const a=A('jump'); return {img:I[a.img], f:landOf(c,a.n)}; }
  }
  const a=A(p.anim); let f=Math.floor(p.t*a.fps);
  f = (p.anim==='cast') ? Math.min(a.n-1,f) : f%a.n;
  return {img:I[a.img], f};
}
function drawSprite(c, sk, img, f, x, y, dir, scale){
  ctx.save(); ctx.translate(Math.floor(x),Math.floor(y)); if(dir<0) ctx.scale(-1,1);
  ctx.imageSmoothingEnabled=false;
  ctx.drawImage(img,f*c.cw,0,c.cw,c.ch,-c.ax*scale,-c.ay*scale,c.cw*scale,c.ch*scale);
  ctx.restore();
}
function drawPlayer(){
  const p=player, c=CH_(), sk=SKN(); const {img,f}=frameFor(c,sk,p);
  if (p.inv>0 && !p.dead && Math.floor(time*20)%2===0) ctx.globalAlpha=.4;
  ctx.fillStyle='rgba(0,0,0,.3)'; const sh=Math.max(.3,1-(GROUND-p.y)/300); ctx.beginPath(); ctx.ellipse(p.x,GROUND+4,26*sh,6*sh,0,0,6.28); ctx.fill();
  drawSprite(c,sk,img,f,p.x,p.y,p.dir,c.scale);
  ctx.globalAlpha=1;
}

function heart(x,y,on){
  ctx.fillStyle=on?'#ff3d6e':'#3a2a4a';
  ctx.fillRect(x+2,y,8,6);ctx.fillRect(x+14,y,8,6);ctx.fillRect(x,y+4,24,8);ctx.fillRect(x+3,y+12,18,5);ctx.fillRect(x+7,y+17,10,4);ctx.fillRect(x+10,y+21,4,3);
  if(on){ctx.fillStyle='#ff9bb5';ctx.fillRect(x+4,y+3,4,4);}
}
function hud(){
  ctx.textAlign='left'; ctx.font='bold 20px monospace';
  for (let i=0;i<player.maxhp;i++) heart(24+i*34,24,i<player.hp);
  ctx.fillStyle='#fff'; ctx.fillText('PONTOS '+score,24,70);
  ctx.textAlign='left'; coinIcon(32,92,9); ctx.fillStyle='#ffd24d'; ctx.fillText(String(coins),50,99);
  ctx.textAlign='right'; ctx.fillStyle='#ffd966'; ctx.fillText('RECORDE '+Math.max(best,score),W-24,36);
  ctx.textAlign='right'; ctx.fillStyle='#b9a2ff'; ctx.fillText(mode==='boss'?'MODO BOSS':'ONDA '+wave,W-24,62);
  if (mode==='boss') bossHud();
}
function centerText(t,y,size,col='#fff'){ ctx.textAlign='center'; ctx.font=`bold ${size}px monospace`; ctx.fillStyle='#000'; ctx.fillText(t,W/2+3,y+3); ctx.fillStyle=col; ctx.fillText(t,W/2,y); }

// ícone de camiseta (skin) em pixel art
function shirtIcon(x,y,s,col){
  ctx.fillStyle=col;
  ctx.fillRect(x+s*3,y,s*2,s); ctx.fillRect(x+s*7,y,s*2,s);          // gola
  ctx.fillRect(x+s*1,y+s,s*10,s*2);                                    // ombros/mangas
  ctx.fillRect(x+s*0,y+s*2,s*3,s*3); ctx.fillRect(x+s*9,y+s*2,s*3,s*3);
  ctx.fillRect(x+s*3,y+s*3,s*6,s*7);                                   // corpo
  ctx.fillStyle='rgba(0,0,0,.35)'; ctx.fillRect(x+s*5,y,s*2,s);
}
function badge(txt,color,cx,y){
  ctx.font='bold 13px monospace'; const w=ctx.measureText(txt).width+18;
  ctx.fillStyle='rgba(0,0,0,.55)'; ctx.fillRect(cx-w/2,y-13,w,19);
  ctx.strokeStyle=color; ctx.lineWidth=2; ctx.strokeRect(cx-w/2,y-13,w,19);
  ctx.fillStyle=color; ctx.textAlign='center'; ctx.fillText(txt,cx,y+1);
}

function titleScreen(){
  ctx.fillStyle='rgba(8,4,24,.62)'; ctx.fillRect(0,0,W,H);
  centerText('MAGOS & ARQUEIROS',78,50,'#c79bff');
  coinCounter(W-20,34);
  ctx.font='16px monospace'; ctx.fillStyle='#ddd'; ctx.textAlign='center'; ctx.fillText('Escolha seu personagem',W/2,112);
  CHAR_IDS.forEach((id,i)=>{
    const c=CHARS[id], sel=id===selChar, sk=c.skins[selSkin[id]], r=cardRect(i), rar=RARITY[sk.rarity], locked=!isUn(id,selSkin[id]);
    ctx.fillStyle=sel?'rgba(120,80,200,.55)':'rgba(30,20,60,.6)'; ctx.fillRect(r.x,r.y,r.w,r.h);
    ctx.lineWidth=sel?4:2; ctx.strokeStyle=sel?'#7dffa8':'#6b5aa0'; ctx.strokeRect(r.x,r.y,r.w,r.h);
    const a=animOf(c,sk,'idle'), f=Math.floor(time*a.fps)%a.n, sc=c.scale*(c.cardK||1.7);
    drawSprite(c,sk,IMG[sk.dir][a.img],f,r.x+r.w/2,r.y+r.h-70,1,sc);
    if (locked){ ctx.fillStyle='rgba(8,4,24,.62)'; ctx.fillRect(r.x+3,r.y+3,r.w-6,r.h-84); drawLock(r.x+r.w/2,r.y+(r.h-84)/2+6,84); }
    ctx.textAlign='center'; ctx.font='bold 17px monospace'; ctx.fillStyle='#fff'; ctx.fillText(c.name,r.x+r.w/2,r.y+r.h-44);
    ctx.font='12px monospace'; ctx.fillStyle='#cfc4ee'; ctx.fillText(sk.name,r.x+r.w/2,r.y+r.h-28);
    badge(rar.label,rar.color,r.x+r.w/2,r.y+r.h-8);
    if (sel){
      ctx.fillStyle=locked?'#ffb020':'#7dffa8'; ctx.font='bold 13px monospace'; ctx.textAlign='left'; ctx.fillText(locked?'BLOQUEADO':'✔ ESCOLHIDO',r.x+10,r.y+24);
      if (locked){ const pr=PRICE[id+':'+selSkin[id]]; if (pr!==undefined){ coinIcon(r.x+18,r.y+43,8); ctx.fillStyle=coins>=pr?'#ffd24d':'#ff8a8a'; ctx.font='bold 15px monospace'; ctx.textAlign='left'; ctx.fillText(String(pr),r.x+32,r.y+49); } }
      const ic=iconRect(i);
      ctx.fillStyle='rgba(15,8,40,.85)'; ctx.fillRect(ic.x,ic.y,ic.w,ic.h);
      ctx.lineWidth=3; ctx.strokeStyle=rar.color; ctx.strokeRect(ic.x,ic.y,ic.w,ic.h);
      shirtIcon(ic.x+10,ic.y+9,2.2,rar.color);
    }
  });
  ctx.fillStyle='#2e9d5b'; ctx.fillRect(playBtn.x,playBtn.y,playBtn.w,playBtn.h);
  ctx.lineWidth=3; ctx.strokeStyle='#bfffd5'; ctx.strokeRect(playBtn.x,playBtn.y,playBtn.w,playBtn.h);
  ctx.fillStyle='#fff'; ctx.font='bold 26px monospace'; ctx.textAlign='center'; ctx.fillText('JOGAR',playBtn.x+playBtn.w/2,playBtn.y+34);
  ctx.fillStyle='#b0361c'; ctx.fillRect(bossBtn.x,bossBtn.y,bossBtn.w,bossBtn.h);
  ctx.strokeStyle='#ffb27a'; ctx.strokeRect(bossBtn.x,bossBtn.y,bossBtn.w,bossBtn.h);
  ctx.fillStyle='#fff'; ctx.font='bold 22px monospace'; ctx.fillText('BOSS DO FOGO',bossBtn.x+bossBtn.w/2,bossBtn.y+32);
  ctx.font='13px monospace'; ctx.fillStyle='#ddd';
  ctx.fillText('Ícone de camiseta = skins e loja  |  ←/→ personagem  S skins  B boss  ENTER jogar',W/2,510);
}
function skinAction(k){
  const ids=skinIds(selChar), id=ids[k], key=selChar+':'+id;
  if (isUn(selChar,id)){ skinCursor=k; equip(selChar,id); beep(620,.1,'triangle',.05,250); return; }
  if (PRICE[key]===undefined){ skinCursor=k; skinMsg={t:2.8,s:'Derrote a CAVEIRA DE FOGO no BOSS DO FOGO para ganhar esta skin!',c:'#ff9a2e'}; beep(160,.15,'square',.04,-60); return; }
  if (skinCursor!==k){ skinCursor=k; skinMsg={t:2.4,s:'Toque de novo para comprar por '+PRICE[key]+' moedas',c:'#ffd24d'}; beep(480,.06,'triangle',.04,100); return; }
  if (coins>=PRICE[key]){ addCoins(-PRICE[key]); unlock(selChar,id); equip(selChar,id); skinMsg={t:2.4,s:'Comprado! Skin equipada.',c:'#7dffa8'}; beep(700,.2,'triangle',.06,500); }
  else { skinMsg={t:2.6,s:'Faltam '+(PRICE[key]-coins)+' moedas. Jogue para ganhar mais!',c:'#ff6b81'}; beep(150,.2,'sawtooth',.05,-60); }
}
function skinsScreen(){
  ctx.fillStyle='rgba(8,4,24,.85)'; ctx.fillRect(0,0,W,H);
  const c=CHARS[selChar], ids=skinIds(selChar);
  centerText('SKINS',58,38,'#c79bff');
  coinCounter(W-20,34);
  ctx.font='bold 18px monospace'; ctx.fillStyle='#b9a2ff'; ctx.textAlign='center'; ctx.fillText(c.name,W/2,90);
  ids.forEach((id,k)=>{
    const sk=c.skins[id], r=skinRect(k,ids.length), rar=RARITY[sk.rarity], un=isUn(selChar,id), price=PRICE[selChar+':'+id];
    const eq = selSkin[selChar]===id && un, cur = k===skinCursor;
    ctx.fillStyle=eq?'rgba(120,80,200,.55)':'rgba(30,20,60,.65)'; ctx.fillRect(r.x,r.y,r.w,r.h);
    ctx.lineWidth=cur||eq?4:2; ctx.strokeStyle=eq?'#7dffa8':(cur?'#fff':rar.color); ctx.strokeRect(r.x,r.y,r.w,r.h);
    if (sk.rarity==='lendaria'){ ctx.strokeStyle='rgba(255,176,32,'+(.4+.4*Math.sin(time*5))+')'; ctx.lineWidth=2; ctx.strokeRect(r.x-4,r.y-4,r.w+8,r.h+8); }
    const a=animOf(c,sk,'idle'), f=Math.floor(time*a.fps)%a.n;
    drawSprite(c,sk,IMG[sk.dir][a.img],f,r.x+r.w/2,r.y+r.h-90,1,c.scale*(c.cardK||1.7));
    if (!un){ ctx.fillStyle='rgba(8,4,24,.62)'; ctx.fillRect(r.x+3,r.y+3,r.w-6,r.h-100); drawLock(r.x+r.w/2,r.y+(r.h-100)/2+6,92); }
    ctx.textAlign='center'; ctx.font='bold 15px monospace'; ctx.fillStyle='#fff'; ctx.fillText(sk.name,r.x+r.w/2,r.y+r.h-58);
    badge(rar.label,rar.color,r.x+r.w/2,r.y+r.h-30);
    if (eq){ ctx.fillStyle='#7dffa8'; ctx.font='bold 13px monospace'; ctx.fillText('✔ EQUIPADA',r.x+r.w/2,r.y+r.h-8); }
    else if (un){ ctx.fillStyle='#ddd'; ctx.font='12px monospace'; ctx.fillText('toque para equipar',r.x+r.w/2,r.y+r.h-8); }
    else if (price!==undefined){ ctx.font='bold 16px monospace'; const t=String(price); const w=ctx.measureText(t).width; coinIcon(r.x+r.w/2-w/2-14,r.y+r.h-13,8); ctx.fillStyle=coins>=price?'#ffd24d':'#ff8a8a'; ctx.textAlign='left'; ctx.fillText(t,r.x+r.w/2-w/2,r.y+r.h-7); ctx.textAlign='center'; }
    else { ctx.fillStyle='#ff9a2e'; ctx.font='bold 12px monospace'; ctx.fillText('VENÇA O BOSS DO FOGO',r.x+r.w/2,r.y+r.h-8); }
  });
  if (skinMsg.t>0){ ctx.font='bold 15px monospace'; ctx.textAlign='center'; ctx.fillStyle='#000'; ctx.fillText(skinMsg.s,W/2+2,437); ctx.fillStyle=skinMsg.c; ctx.fillText(skinMsg.s,W/2,435); }
  ctx.font='bold 13px monospace';
  let lx=W/2-170; for (const k in RARITY){ ctx.fillStyle=RARITY[k].color; ctx.fillRect(lx,455,12,12); ctx.fillStyle='#ddd'; ctx.textAlign='left'; ctx.fillText(RARITY[k].label,lx+18,466); lx+=120; }
  ctx.fillStyle='#444'; ctx.fillRect(backBtn.x,backBtn.y,backBtn.w,backBtn.h);
  ctx.lineWidth=3; ctx.strokeStyle='#bbb'; ctx.strokeRect(backBtn.x,backBtn.y,backBtn.w,backBtn.h);
  ctx.fillStyle='#fff'; ctx.font='bold 20px monospace'; ctx.textAlign='center'; ctx.fillText('VOLTAR',W/2,backBtn.y+28);
}
function winScreen(){
  ctx.fillStyle='rgba(10,0,20,'+Math.min(.65,winT*.5)+')'; ctx.fillRect(0,0,W,H);
  if (winT>.8){
    centerText('VITÓRIA!',200,64,'#ffd24d');
    centerText('Baú aberto: +200 moedas',262,26,'#fff');
    if (gotFire) centerText('Skin CAVALEIRO DE FOGO desbloqueada!',304,24,'#ff9a2e');
    else centerText('Você já tinha a skin de fogo',304,20,'#cfc4ee');
    if (winT>2.2) centerText('Toque / ENTER para voltar ao menu',366,22,'#7dffa8');
  }
}
function deadScreen(){
  ctx.fillStyle=`rgba(10,0,20,${Math.min(.7,deadT*.5)})`; ctx.fillRect(0,0,W,H);
  if (deadT>1){ centerText('FIM DE JOGO',230,60,'#ff5577'); centerText('Pontos: '+score+'   Recorde: '+best,290,26); if(deadT>1.5) centerText('Toque / ENTER para voltar ao menu',350,22,'#7dffa8'); }
}

// ---------- Loop ----------
let last=0;
function startMode(m){
  if (!isUn(selChar,selSkin[selChar])){ skinMsg={t:2.8,s:'Personagem bloqueado! Compre uma skin aqui.',c:'#ffb020'}; openSkins(); return; }
  reset(m); state='play';
}
function frame(ts){
  const dt=Math.min(.033,(ts-last)/1000||0); last=ts;
  touchEl.classList.toggle('hide', state==='title'||state==='skins');
  const go = press.Enter||press.Space||press.TJ||press.TC||press.KeyJ;
  skinMsg.t=Math.max(0,skinMsg.t-dt);
  if (state==='title'){
    const idx=CHAR_IDS.indexOf(selChar);
    if (press.KeyS) openSkins();
    else if (press.ArrowLeft||press.KeyA||press.TL){ selectChar(CHAR_IDS[(idx+CHAR_IDS.length-1)%CHAR_IDS.length]); beep(520,.08,'triangle',.05,200); }
    else if (press.ArrowRight||press.KeyD||press.TR){ selectChar(CHAR_IDS[(idx+1)%CHAR_IDS.length]); beep(520,.08,'triangle',.05,200); }
    else if (press.KeyB) startMode('boss');
    else if (go) startMode('normal');
    time+=dt;
  } else if (state==='skins'){
    time+=dt;
    const ids=skinIds(selChar);
    if (press.ArrowLeft||press.KeyA||press.TL) skinCursor=(skinCursor+ids.length-1)%ids.length;
    else if (press.ArrowRight||press.KeyD||press.TR) skinCursor=(skinCursor+1)%ids.length;
    else if (press.Enter||press.TJ||press.Space) skinAction(skinCursor);
    else if (press.Escape||press.Backspace||press.TC||press.KeyS) state='title';
  } else {
    if (state==='dead' && deadT>1.5 && go){ reset('normal'); state='title'; }
    else if (state==='win' && winT>2.2 && go){ reset('normal'); state='title'; }
    update(dt);
  }
  ctx.imageSmoothingEnabled=false;
  drawBG();
  if (mode==='boss'){ ctx.fillStyle='rgba(120,20,0,.22)'; ctx.fillRect(0,0,W,H); }
  drawWorld();
  if (state==='title') titleScreen();
  else if (state==='skins') skinsScreen();
  else { hud(); drawBanner(); if (state==='dead') deadScreen(); if (state==='win') winScreen(); }
  for (const k in press) delete press[k];
  requestAnimationFrame(frame);
}
function start(){ reset('normal'); state='title'; requestAnimationFrame(frame); }
})();
